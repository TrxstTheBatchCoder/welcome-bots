/* Please check https://github.com/LegendaryEmoji/welcome-bot/wiki/Config for information */
/* Make sure to turn on Server Members intent on discord developer portal or you will get some error & won't be able to get welcome/goodbye message & image */

const config = {
  Token: "",
  Default_Prefix: "",
  Color: "",
  Welcome_Images: "",
  GoodBye_Images: "",
  Support: "",
};

module.exports = config;
